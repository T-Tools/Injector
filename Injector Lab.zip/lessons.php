
<div id="top">
  <marquee style="color:red;">+++ The Moon Have Its Own Light And Also A Candle Have Its Own Light +++</marquee>
  <a href="index.php" id="h">The Injector,Zero To Hero</a><br>By CyberBullet<br>
<a href="Lesson-1.php">Lesson-1</a>
<a href="Lesson-2.php">Lesson-2</a>
<a href="Lesson-3.php">Lesson-3</a>
<a href="Lesson-4.php">Lesson-4</a>
<a href="Lesson-5.php">Lesson-5</a>
<a href="Lesson-6.php">Lesson-6</a>
<a href="Lesson-7.php">Lesson-7</a>
<a href="Lesson-8.php">Lesson-8</a>
<a href="Lesson-9.php">Lesson-9</a>
<a href="Lesson-10.php">Lesson-10</a>
<a href="Lesson-11.php">Lesson-11</a>
<a href="Lesson-12.php">Lesson-12</a>
<a href="Lesson-13.php">Lesson-13</a>
<a href="Lesson-14.php">Lesson-14</a>
<a href="Lesson-15.php">Lesson-15</a>
<a href="Lesson-16.php">Lesson-16</a>
<a href="Lesson-17.php">Lesson-17</a>
<a href="Lesson-18.php">Lesson-18</a>
<a href="Lesson-19.php">Lesson-19</a>
<a href="Lesson-20.php">Lesson-20</a>
</div>